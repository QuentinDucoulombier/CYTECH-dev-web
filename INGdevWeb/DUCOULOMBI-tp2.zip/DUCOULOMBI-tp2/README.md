# TASSTAITIDN


---

Auteur: Quentin Ducoulombier  
Date: 22/03/23  
Email: ducoulombi@cy-tech.fr

---

## Comment lancer le site web

Pour lancer le site web il existe 2 solutions:
- Le lancer directement dans le repertoire ```DUCOULOMBI-tp2``` 
- Directement dans la console et dans le meme repertoire en lancant la commande: 
```bash
chrome index.html  
firefox index.html
```

